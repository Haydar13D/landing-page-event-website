<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pameran Laptop 2025 - Convention Hall Tirtonadi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1>Pameran Laptop 2025</h1>
                    <p class="lead">Convention Hall Tirtonadi</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p>23-25 Mei 2025</p>
                    <a href="register.php" class="btn btn-primary">Daftar Sekarang</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero-section py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2 text-center">
                    <h2 class="display-4">Pameran Laptop Terbesar Tahun Ini!</h2>
                    <p class="lead">Temukan koleksi laptop terbaru dari berbagai brand ternama dengan harga spesial dan promo eksklusif selama pameran.</p>
                    <div class="mt-4">
                        <a href="#exhibitors" class="btn btn-lg btn-outline-dark me-2">Lihat Exhibitor</a>
                        <a href="register.php" class="btn btn-lg btn-primary">Dapatkan Tiket</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>Tentang Pameran</h2>
                    <p>Pameran Laptop 2025 merupakan event tahunan yang menampilkan produk-produk laptop terbaru dari berbagai brand ternama. Pengunjung dapat melihat, mencoba, dan membeli laptop dengan harga spesial dan promo eksklusif selama pameran.</p>
                    <p>Pameran ini juga menghadirkan beragam workshop dan seminar seputar teknologi komputer yang dapat diikuti oleh pengunjung.</p>
                </div>
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-body">
                            <h3>Informasi Event</h3>
                            <ul class="list-unstyled">
                                <li><strong>Tanggal:</strong> 23-25 Mei 2025</li>
                                <li><strong>Waktu:</strong> 10.00 - 21.00 WIB</li>
                                <li><strong>Lokasi:</strong> Convention Hall Tirtonadi</li>
                                <li><strong>Tiket Regular:</strong> Rp25.000</li>
                                <li><strong>Tiket VIP:</strong> Rp75.000</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Exhibitors Section -->
    <section id="exhibitors" class="exhibitors-section py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-4">Exhibitor</h2>
            <div class="row">
                <?php
                // Contoh data exhibitor, dalam implementasi sebenarnya data ini diambil dari database
                $exhibitors = [
                    ["name" => "Brand A", "booth" => "A1", "desc" => "Brand laptop premium dengan performa tinggi"],
                    ["name" => "Brand B", "booth" => "B2", "desc" => "Laptop gaming dengan spesifikasi terbaik"],
                    ["name" => "Brand C", "booth" => "C3", "desc" => "Laptop bisnis dengan harga terjangkau"],
                    ["name" => "Brand D", "booth" => "D4", "desc" => "Ultrabook ringan dan ramping"]
                ];

                foreach ($exhibitors as $exhibitor) {
                    echo '<div class="col-md-3 mb-4">';
                    echo '<div class="card h-100">';
                    echo '<div class="card-body">';
                    echo '<h5 class="card-title">' . $exhibitor["name"] . '</h5>';
                    echo '<h6 class="card-subtitle mb-2 text-muted">Booth: ' . $exhibitor["booth"] . '</h6>';
                    echo '<p class="card-text">' . $exhibitor["desc"] . '</p>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- Schedule Section -->
    <section class="schedule-section py-5">
        <div class="container">
            <h2 class="text-center mb-4">Jadwal Acara</h2>
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Acara</th>
                                    <th>Tanggal</th>
                                    <th>Waktu</th>
                                    <th>Lokasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Contoh data jadwal, dalam implementasi sebenarnya data ini diambil dari database
                                $events = [
                                    ["title" => "Opening Ceremony", "date" => "23 Mei 2025", "time" => "10:00 - 11:00", "location" => "Main Stage"],
                                    ["title" => "Laptop Gaming Showcase", "date" => "23 Mei 2025", "time" => "13:00 - 15:00", "location" => "Hall A"],
                                    ["title" => "Workshop: Desain Grafis", "date" => "24 Mei 2025", "time" => "10:00 - 12:00", "location" => "Workshop Room"],
                                    ["title" => "Laptop untuk Content Creator", "date" => "24 Mei 2025", "time" => "15:00 - 17:00", "location" => "Main Stage"],
                                    ["title" => "Closing & Lucky Draw", "date" => "25 Mei 2025", "time" => "19:00 - 21:00", "location" => "Main Stage"]
                                ];

                                foreach ($events as $event) {
                                    echo '<tr>';
                                    echo '<td>' . $event["title"] . '</td>';
                                    echo '<td>' . $event["date"] . '</td>';
                                    echo '<td>' . $event["time"] . '</td>';
                                    echo '<td>' . $event["location"] . '</td>';
                                    echo '</tr>';
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Ticket Section -->
    <section class="ticket-section py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-4">Dapatkan Tiket Anda</h2>
            <div class="row">
                <div class="col-md-4 offset-md-2 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <h3 class="card-title">Regular Ticket</h3>
                            <h4 class="card-subtitle mb-2">Rp25.000</h4>
                            <ul class="list-unstyled">
                                <li>Akses ke pameran</li>
                                <li>Kesempatan mengikuti lucky draw</li>
                                <li>Akses ke semua booth exhibitor</li>
                            </ul>
                            <a href="register.php?type=regular" class="btn btn-primary">Beli Tiket</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-body text-center">
                            <h3 class="card-title">VIP Ticket</h3>
                            <h4 class="card-subtitle mb-2">Rp75.000</h4>
                            <ul class="list-unstyled">
                                <li>Semua manfaat tiket Regular</li>
                                <li>Akses ke workshop eksklusif</li>
                                <li>Souvenir eksklusif</li>
                                <li>Priority entry (tidak perlu antre)</li>
                            </ul>
                            <a href="register.php?type=vip" class="btn btn-primary">Beli Tiket</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h4>Pameran Laptop 2025</h4>
                    <p>Convention Hall Tirtonadi<br>23-25 Mei 2025</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h4>Kontak</h4>
                    <p>Email: info@pameranlaptop.com<br>Telepon: 0812-3456-7890</p>
                    <div class="social-media">
                        <a href="#" class="text-white me-2">Facebook</a>
                        <a href="#" class="text-white me-2">Instagram</a>
                        <a href="#" class="text-white">Twitter</a>
                    </div>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12 text-center">
                    <p class="mb-0">&copy; 2025 Pameran Laptop. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>