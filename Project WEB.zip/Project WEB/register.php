<?php
// Include database connection
require_once 'db-connect.php';

// Initialize variables
$error = '';
$success = false;

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate input
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    
    // Simple validation
    if (empty($name) || empty($phone)) {
        $error = "Semua field harus diisi.";
    } else {
        // Get existing ticket
        $ticketSql = "SELECT * FROM tiket LIMIT 1";
        $ticketResult = $conn->query($ticketSql);
        
        if ($ticketResult->num_rows > 0) {
            $ticket = $ticketResult->fetch_assoc();
            $ticketId = $ticket['id'];
            
            // Current timestamp for registration time
            $registrationTime = date('Y-m-d H:i:s');
            
            // Insert data into user table
            $sql = "INSERT INTO user (nama, no_hp, waktu_registrasi, tiket_id) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $name, $phone, $registrationTime, $ticketId);
            
            if ($stmt->execute()) {
                // Set success flag and redirect to confirmation page
                $userId = $stmt->insert_id;
                $success = true;
                header("Location: confirmation.php?id=" . $userId);
                exit();
            } else {
                $error = "Terjadi kesalahan saat mendaftar. Silakan coba lagi. " . $conn->error;
            }
        } else {
            $error = "Tidak ada tiket yang tersedia.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrasi Tiket - Pameran Laptop 2025</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white py-3">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1>Pameran Laptop 2025</h1>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="index.php" class="btn btn-outline-light">Kembali ke Home</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Registration Form -->
    <section class="registration-section py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card">
                        <div class="card-header bg-primary text-white">
                            <h2 class="mb-0">Registrasi Tiket Pameran Laptop</h2>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($error)): ?>
                                <div class="alert alert-danger"><?php echo $error; ?></div>
                            <?php endif; ?>

                            <div class="ticket-info mb-4">
                                <h3>Tiket Pameran Laptop 2025</h3>
                                <p>Tiket untuk mengunjungi Pameran Laptop 2025 di Convention Hall Tirtonadi</p>
                            </div>

                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Nama Lengkap</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="phone" class="form-label">Nomor Telepon</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" required>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="terms" required>
                                    <label class="form-check-label" for="terms">Saya setuju dengan syarat dan ketentuan</label>
                                </div>
                                
                                <div class="d-grid">
                                    <button type="submit" class="btn btn-primary">Daftar Sekarang</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h4>Pameran Laptop 2025</h4>
                    <p>Convention Hall Tirtonadi<br>23-25 Mei 2025</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h4>Kontak</h4>
                    <p>Email: info@pameranlaptop.com<br>Telepon: 0812-3456-7890</p>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12 text-center">
                    <p class="mb-0">&copy; 2025 Pameran Laptop. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>