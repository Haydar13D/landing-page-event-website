<?php
// Database connection file
$host = "localhost"; // Your database host
$username = "root"; // Your database username (default for XAMPP)
$password = ""; // Your database password (empty by default for XAMPP)
$database = "laptop_fair"; // Database name

// Create connection to database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Set character set
$conn->set_charset("utf8mb4");