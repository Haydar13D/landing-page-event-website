<?php
// Include database connection
require_once 'db-connect.php';

// Initialize variables
$user = null;
$error = '';

// Check if we have a user ID
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $userId = (int)$_GET['id'];
    
    // Get user information with ticket
    $sql = "SELECT u.*, t.id as ticket_id 
            FROM user u 
            JOIN tiket t ON u.tiket_id = t.id 
            WHERE u.id = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        $error = "Tiket tidak ditemukan.";
    }
} else {
    $error = "ID tiket tidak valid.";
}

// Generate unique ticket number based on user ID and registration time
$ticketNumber = "";
if ($user) {
    // Create a ticket number format: LF-{YEAR}-{USER_ID}-{RANDOM_4_DIGITS}
    $year = date('Y', strtotime($user['waktu_registrasi']));
    $random = str_pad(rand(1000, 9999), 4, '0', STR_PAD_LEFT);
    $ticketNumber = "LF-{$year}-{$user['id']}-{$random}";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Tiket - Pameran Laptop 2025</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Custom styles for the ticket */
        .ticket-container {
            max-width: 800px;
            margin: 0 auto;
            border: 2px dashed #ccc;
            padding: 20px;
            background-color: #f9f9f9;
            position: relative;
            overflow: hidden;
        }
        
        .ticket-header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            margin: -20px -20px 20px -20px;
            text-align: center;
        }
        
        .ticket-number {
            font-size: 22px;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
        }
        
        .ticket-watermark {
            position: absolute;
            opacity: 0.05;
            font-size: 150px;
            transform: rotate(-45deg);
            top: 50%;
            left: 50%;
            margin-top: -75px;
            margin-left: -150px;
            font-weight: bold;
            color: #000;
            z-index: 0;
        }
        
        .ticket-info {
            position: relative;
            z-index: 1;
        }
        
        .ticket-qr {
            text-align: center;
            margin: 15px 0;
        }
        
        .ticket-qr img {
            max-width: 150px;
        }
        
        .ticket-footer {
            margin-top: 20px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
        
        .scissors {
            height: 20px;
            border-top: 2px dashed #ccc;
            margin: 30px 0;
            position: relative;
        }
        
        .scissors:before {
            content: "✂";
            position: absolute;
            top: -15px;
            left: 10px;
            font-size: 20px;
            color: #999;
        }
        
        @media print {
            .no-print {
                display: none !important;
            }
            
            body {
                margin: 0;
                padding: 0;
                background: #fff;
            }
            
            .ticket-container {
                width: 100%;
                max-width: 100%;
                border: 2px dashed #000;
            }
            
            .container {
                width: 100%;
                max-width: 100%;
                padding: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Header - Will not be printed -->
    <header class="bg-dark text-white py-3 no-print">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1>Pameran Laptop 2025</h1>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="index.php" class="btn btn-outline-light">Kembali ke Home</a>
                </div>
            </div>
        </div>
    </header>

    <!-- Confirmation Section -->
    <section class="confirmation-section py-5">
        <div class="container">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php elseif ($user): ?>
                <div class="row mb-4 no-print">
                    <div class="col-md-12 text-center">
                        <h2>Pendaftaran Berhasil!</h2>
                        <p class="lead">Silakan cetak tiket dibawah ini sebagai syarat masuk ke Pameran Laptop 2025.</p>
                        <button onclick="window.print();" class="btn btn-primary mt-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-printer" viewBox="0 0 16 16">
                                <path d="M2.5 8a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z"/>
                                <path d="M5 1a2 2 0 0 0-2 2v2H2a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h1v1a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1h1a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-1V3a2 2 0 0 0-2-2H5zM4 3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2H4V3zm1 5a2 2 0 0 0-2 2v1H2a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-1v-1a2 2 0 0 0-2-2H5zm7 2v3a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1z"/>
                            </svg>
                            Cetak Tiket
                        </button>
                    </div>
                </div>
                
                <div class="scissors no-print"></div>
                
                <!-- Printable Ticket -->
                <div class="ticket-container">
                    <div class="ticket-watermark">LAPTOP FAIR</div>
                    
                    <div class="ticket-header">
                        <h2>PAMERAN LAPTOP 2025</h2>
                        <p>Convention Hall Tirtonadi | 23-25 Mei 2025</p>
                    </div>
                    
                    <div class="ticket-number">
                        No. Tiket: <?php echo $ticketNumber; ?>
                    </div>
                    
                    <div class="ticket-info">
                        <div class="row">
                            <div class="col-md-7">
                                <table class="table table-borderless">
                                    <tr>
                                        <th width="140">Nama</th>
                                        <td>: <strong><?php echo htmlspecialchars($user['nama']); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <th>No. Telepon</th>
                                        <td>: <?php echo htmlspecialchars($user['no_hp']); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Waktu Registrasi</th>
                                        <td>: <?php echo date('d M Y H:i', strtotime($user['waktu_registrasi'])); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Jenis Tiket</th>
                                        <td>: Regular</td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-5">
                                <div class="ticket-qr">
                                    <!-- Simple placeholder for QR code -->
                                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?php echo urlencode($ticketNumber); ?>" alt="QR Code">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="ticket-footer">
                        <p><strong>PENTING</strong>: Tiket ini harus dibawa dan ditunjukkan saat memasuki area pameran.</p>
                        <p>Jam Operasional: 10.00 - 21.00 WIB</p>
                    </div>
                </div>
                
                <div class="scissors no-print"></div>
                
                <div class="row mt-4 no-print">
                    <div class="col-md-12 text-center">
                        <p>Informasi tambahan akan dikirimkan melalui SMS ke nomor yang telah didaftarkan.</p>
                        <a href="index.php" class="btn btn-outline-dark mt-2">Kembali ke Home</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer - Will not be printed -->
    <footer class="bg-dark text-white py-4 no-print">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h4>Pameran Laptop 2025</h4>
                    <p>Convention Hall Tirtonadi<br>23-25 Mei 2025</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h4>Kontak</h4>
                    <p>Email: info@pameranlaptop.com<br>Telepon: 0812-3456-7890</p>
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-12 text-center">
                    <p class="mb-0">&copy; 2025 Pameran Laptop. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>